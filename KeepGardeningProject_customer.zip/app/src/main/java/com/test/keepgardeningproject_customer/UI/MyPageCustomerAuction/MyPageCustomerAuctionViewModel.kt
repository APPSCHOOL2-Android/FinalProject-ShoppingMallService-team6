package com.test.keepgardeningproject_customer.UI.MyPageCustomerAuction

import androidx.lifecycle.ViewModel

class MyPageCustomerAuctionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}