package com.test.keepgardeningproject_customer.UI.HomeCustomerSearch

import androidx.lifecycle.ViewModel

class HomeCustomerSearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}