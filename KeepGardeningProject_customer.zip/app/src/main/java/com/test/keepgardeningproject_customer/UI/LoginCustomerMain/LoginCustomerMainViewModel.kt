package com.test.keepgardeningproject_customer.UI.LoginCustomerMain

import androidx.lifecycle.ViewModel

class LoginCustomerMainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}