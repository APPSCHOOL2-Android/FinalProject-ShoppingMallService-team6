package com.test.keepgardeningproject_customer.UI.MyPageCustomerModify

import androidx.lifecycle.ViewModel

class MyPageCustomerModifyViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}