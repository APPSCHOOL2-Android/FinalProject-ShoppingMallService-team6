package com.test.keepgardeningproject_customer.UI.MyPageCustomerWish

import androidx.lifecycle.ViewModel

class MyPageCustomerWishViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}