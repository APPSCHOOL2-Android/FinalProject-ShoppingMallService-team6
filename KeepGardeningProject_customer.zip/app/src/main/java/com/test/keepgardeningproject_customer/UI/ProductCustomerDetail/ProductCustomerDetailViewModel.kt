package com.test.keepgardeningproject_customer.UI.ProductCustomerDetail

import androidx.lifecycle.ViewModel

class ProductCustomerDetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}