package com.test.keepgardeningproject_customer.UI.MyPageCustomerQnADetail

import androidx.lifecycle.ViewModel

class MyPageCustomerQnADetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}