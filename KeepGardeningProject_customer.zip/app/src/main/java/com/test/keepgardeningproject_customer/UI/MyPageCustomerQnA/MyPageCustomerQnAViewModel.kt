package com.test.keepgardeningproject_customer.UI.MyPageCustomerQnA

import androidx.lifecycle.ViewModel

class MyPageCustomerQnAViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}