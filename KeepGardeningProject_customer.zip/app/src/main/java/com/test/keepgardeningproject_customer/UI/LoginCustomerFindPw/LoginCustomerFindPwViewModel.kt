package com.test.keepgardeningproject_customer.UI.LoginCustomerFindPw

import androidx.lifecycle.ViewModel

class LoginCustomerFindPwViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}