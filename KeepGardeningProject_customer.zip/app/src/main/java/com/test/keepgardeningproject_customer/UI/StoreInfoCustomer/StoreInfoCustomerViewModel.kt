package com.test.keepgardeningproject_customer.UI.StoreInfoCustomer

import androidx.lifecycle.ViewModel

class StoreInfoCustomerViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}