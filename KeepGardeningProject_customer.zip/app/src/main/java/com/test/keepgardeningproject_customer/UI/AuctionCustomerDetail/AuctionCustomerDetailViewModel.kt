package com.test.keepgardeningproject_customer.UI.AuctionCustomerDetail

import androidx.lifecycle.ViewModel

class AuctionCustomerDetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}