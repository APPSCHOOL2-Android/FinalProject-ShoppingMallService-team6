package com.test.keepgardeningproject_customer.UI.AuctionCustomer

import androidx.lifecycle.ViewModel

class AuctionCustomerViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}