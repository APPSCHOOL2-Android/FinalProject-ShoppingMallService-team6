package com.test.keepgardeningproject_customer.UI.AlertCustomer

import androidx.lifecycle.ViewModel

class AlertCustomerViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}