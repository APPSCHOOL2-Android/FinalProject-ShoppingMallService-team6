package com.test.keepgardeningproject_customer.UI.HomeCustomerMain

import androidx.lifecycle.ViewModel

class HomeCustomerMainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}