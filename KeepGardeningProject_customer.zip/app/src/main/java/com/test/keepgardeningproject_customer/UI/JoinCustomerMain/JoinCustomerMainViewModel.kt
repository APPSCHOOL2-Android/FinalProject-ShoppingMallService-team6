package com.test.keepgardeningproject_customer.UI.JoinCustomerMain

import androidx.lifecycle.ViewModel

class JoinCustomerMainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}