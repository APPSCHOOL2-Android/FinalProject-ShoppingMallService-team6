package com.test.keepgardeningproject_customer.UI.MyPageCustomerPurchase

import androidx.lifecycle.ViewModel

class MyPageCustomerPurchaseViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}