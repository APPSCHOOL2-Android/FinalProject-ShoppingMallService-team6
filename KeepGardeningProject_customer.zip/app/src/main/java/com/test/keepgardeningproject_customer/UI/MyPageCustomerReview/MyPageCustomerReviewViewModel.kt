package com.test.keepgardeningproject_customer.UI.MyPageCustomerReview

import androidx.lifecycle.ViewModel

class MyPageCustomerReviewViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}