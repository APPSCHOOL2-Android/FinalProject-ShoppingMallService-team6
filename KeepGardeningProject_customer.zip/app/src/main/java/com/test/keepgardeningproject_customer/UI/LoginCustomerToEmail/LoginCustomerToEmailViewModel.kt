package com.test.keepgardeningproject_customer.UI.LoginCustomerToEmail

import androidx.lifecycle.ViewModel

class LoginCustomerToEmailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}