package com.test.keepgardeningproject_customer.UI.StoreInfoCustomerDetail

import androidx.lifecycle.ViewModel

class StoreInfoCustomerDetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}