package com.test.keepgardeningproject_customer.UI.MyPageCustomerReviewDetail

import androidx.lifecycle.ViewModel

class MyPageCustomerReviewDetailViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}